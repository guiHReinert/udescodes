#include "arq.h"

// Criar novo descritor sem referencial movel
descS *criaDescF(int tamInfo){   	
    descS *desc = (descS*) malloc(sizeof(descS));
    
    if(!desc) {
        printf("Erro ao alocar memoria para o descritor\n");
        return NULL;
    }

    desc->cauda = NULL;
    desc->frente = NULL;
    desc->tamInfo = tamInfo;

    return desc;
}

// Remover descritor da memoria
descS *destroiDescF(descS *desc){
    reinicia(desc);
    free(desc);
    return NULL; // Aterra o ponteiro externo, declarado na aplicacao
}
/*
    Insere nodos na fila a partir da cauda, com base nas suas prioridades:
    - <novo>      dados do novo nodo (chamado de <newNodo>);
    - <desc>      ponteiro para o descritor da fila;
    - <compara>   eh a funcao de comparacao utilizada no contexto. Portanto, variavel;
    - <count>     incrementa sempre que while_1() for executado. (unica iteracao
                  da funcao)

    As filas aqui consideradas nao possuem "buracos", ou seja, espacos vazios
    entre nodos. Bem como descS->cauda->anterior == NULL e
    descS->frente->posterior == NULL.
*/
int inserirSem(info *novo, descS *desc, int (*compara)(info *novo, info *walker)){

    // Resultado da comparacao e definicao dos nodos uteis ah funcao.
	int result;
  	nodo *newNodo=NULL, *walker=NULL;
      
    // Alocar dinamicamente o novo nodo vazio, e verificar se a alocacao funcionou.
    newNodo = (nodo*) malloc(sizeof(nodo));
    if (!newNodo){
        printf("Erro ao alocar memoria para o novo nodo\n");
        return FRACASSO;
    } 

    // Copiar as novas informacoes de <novo> para <newNodo->dados>.
    memcpy(&(newNodo->dados), novo, desc->tamInfo);
    newNodo->anterior = NULL;
    newNodo->posterior = NULL;

    /*
        Fila vazia:
        - Ponteiros de <newNodo> vazios, frente e cauda apontam para <newNodo>.
    */
    if(desc->frente == NULL && desc->cauda == NULL){
        desc->frente = newNodo;
        desc->cauda = newNodo;
    }

    // Fila com pelo menos 1 nodo
    else{

        /*
            <newNodo> eh de menor prioridade que a cauda.
            - <newNodo->anterior>   aponta para NULL;
            - <newNodo->posterior>  aponta para a cauda;
            - <desc->cauda>         aponta para <newNodo>;
        */
        if(compara(novo, &(desc->cauda->dados)) == MENOR || compara(novo, &(desc->cauda->dados)) == IGUAL){
            newNodo->posterior = desc->cauda;
            desc->cauda->anterior = newNodo;
            desc->cauda = newNodo;
            // printf("Inserido na cauda\n");
        }

        /*
            <newNodo> eh de maior prioridade que a frente.
            - <newNodo->anterior>   aponta para a frente;
            - <newNodo->posterior>  aponta para NULL;
            - <desc->frente>        aponta para <newNodo>;
        */
        else if(compara(novo, &(desc->frente->dados)) == MAIOR){
            newNodo->anterior = desc->frente;
            desc->frente->posterior = newNodo;
            desc->frente = newNodo;
            // printf("Inserido na frente\n");

        }
        
        // <newNodo> possui prioridade maior que a da cauda e menor que a da frente
        else{
            
            /*
                while_1: <walker> irah percorrer a fila pela cauda ate que
                a sua prioridade seja imediatamente maior que a de <newNodo>.
            */
            walker = desc->cauda; 
            while(walker->posterior != NULL && (*compara)(novo, &(walker->dados)) == MAIOR){
                walker = walker->posterior;
                desc->numRep++;
            }

            /*
                Sempre valerah quando:
                - <newNodo->anterior>   apontar para a cauda;
                - <newNodo->posterior>  apontar para a frente;
                - <newNodo>             estiver em qualquer outra posicao entre
                                        os dois.
            */
            newNodo->posterior = walker;
            newNodo->anterior = walker->anterior;
            walker->anterior->posterior = newNodo;
            walker->anterior = newNodo;
            // printf("Inserido no intermediario\n");
        }	
    }
    return SUCESSO;
}

// Remover nodos na fila (iteracao comecando pela cauda)
int remove_(info *reg, descS  *desc){
	int ans = FRACASSO;
	nodo *aux = desc->cauda;
    // Fila nao vazia
    if(desc->cauda != NULL && desc->frente != NULL){
       	memcpy(reg, &(desc->frente->dados), desc->tamInfo);
		if(aux == desc->frente) { // Caso tenha 1 elemento apenas
			free(desc->frente);
			desc->frente = desc->cauda = NULL;
		}
		else {
			desc->frente= desc->frente->anterior;
            free(desc->frente->posterior); 
            desc->frente->posterior = NULL;
		}
		ans = SUCESSO;
	}
	return ans;
}
// Reiniciar fila
int reinicia(descS *desc){
	int ret=FRACASSO;
    nodo *aux=NULL;
    if(desc->frente != NULL && desc->cauda != NULL){  
        aux = desc->cauda->posterior;
        while(aux != NULL) {
            free(desc->cauda);
            desc->cauda = aux;
            aux = aux->posterior;
        }
        free(desc->cauda);
        desc->frente = NULL;
        desc->cauda = NULL;
        ret=SUCESSO; 
    }
    return ret;	
}

// Buscar frente da fila
int buscaNaFrente(info *reg, descS *desc){  
    int ret = FRACASSO;
    if(desc->frente != NULL && desc->cauda != NULL) { 	
        memcpy(reg, &(desc->frente->dados), desc->tamInfo);
        ret = SUCESSO;
    }
    return ret;
}
// Buscar cauda da fila
int buscaNaCauda(info *reg, descS *desc){
    int ret = FRACASSO;
    if(desc->cauda != NULL && desc->frente != NULL) {
        memcpy(reg, &(desc->cauda->dados), desc->tamInfo);
	    ret = SUCESSO;
    }
    return ret;
}

// Verificar se estah vazia
int testaVazia(descS *desc){
    if(desc->frente == NULL && desc->cauda == NULL) {
        return SIM;
    }
    return NAO;
}

